
#ifndef DHT11_H
#define DHT11_H

#define DHT11_OK 0

int DHT11_ReadData(float *temperature, float *humidity);

#endif // DHT11_H
